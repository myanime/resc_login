# Create your tests here.
sites = ['fff','ggg','aaa']
SITES = []
for site in sites:
    SITES.append((site, site))
print tuple(SITES)
    
