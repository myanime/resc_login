from __future__ import unicode_literals

from django.apps import AppConfig


class ModifyDatabaseConfig(AppConfig):
    name = 'modify_database'
