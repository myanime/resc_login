Version 1.1
- 2captcha solver implemented
- login method broken
- rescator specific methods removed
- database schema:
    fields:
        checkboxes
        usernames
        passwords
        custom - can enter custom string to be entered into the custom xpath
- dreammarket_document.json demonstrates a bare minimum schema. You can have more
but this is what is needed to generate a login.
    
