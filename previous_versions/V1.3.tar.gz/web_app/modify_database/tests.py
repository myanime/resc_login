# Create your tests here.
import sys
path = sys.path[1] + '/classes'
sys.path.insert(0, path)
from modifyDAO import *

tes()